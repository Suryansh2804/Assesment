// tests/login.spec.js
import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage.js';
import loginData from '../test-data/loginData.json';

loginData.forEach(({ username, password, expected }) => {
  test(`Login - ${expected} case: ${username}`, async ({ page }) => {
    const loginPage = new LoginPage(page);
    await loginPage.goto();
    await loginPage.login(username, password);

    if (expected === 'success') {
      await expect(page).toHaveURL(/dashboard/); // Adjust for success redirect
    } else {
      await expect(loginPage.errorMessage).toBeVisible();
      await expect(loginPage.errorMessage).toContainText(/invalid/); // Validate error
    }
  });
});
